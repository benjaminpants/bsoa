Don't extract this.

Also thanks for downloading!
Please do not try using the simple quick cube spawner as it literally doesn't exist anymore.
- Ben, AKA MissingTextureMan101